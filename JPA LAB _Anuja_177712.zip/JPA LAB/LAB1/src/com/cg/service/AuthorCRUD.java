package com.cg.service;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.eclipse.persistence.sessions.Session;
import org.eclipse.persistence.sessions.factories.SessionFactory;

import com.cg.entity.Author;

public class AuthorCRUD {
	
	@SuppressWarnings("unchecked")
	public static void main(String args[]) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("LAB1");
		EntityManager em=emf.createEntityManager();
		Scanner sc=new Scanner(System.in);
		Author a;
		char key;
		System.out.print("1.Insert 2.Update 3.Delete 4.Show All 5.Exit\nEnter Choice: ");
		key=sc.next().charAt(0);
		
		while(true) {
		switch (key) {
			case '1':
				a=new Author();
				em.getTransaction().begin();
					System.out.print("First Name: ");
					a.setFirstName(sc.next());
					System.out.print("Middle Name: ");
					a.setMiddleName(sc.next());
					System.out.print("Last Name: ");
					a.setLastName(sc.next());
					System.out.print("Phone No.: ");
					a.setPhoneNo(sc.next());
					em.persist(a);
					em.getTransaction().commit();
					System.out.println("Succesfully Added the Record! Your Id is: "+a.getAuthorId());
				break;
	
			case '2':
				a=new Author();
				char updateKey;
				em.getTransaction().begin();
					System.out.print("1.First Name 2.Middle Name 3.Last Name 4.Phone No.\nEnter Choice: ");
					updateKey=sc.next().charAt(0);
					System.out.println("Enter Author ID: ");
					a=em.find(Author.class,sc.nextInt());
					
					switch (updateKey) {
					
					case '1':
						System.out.print("Enter First Name: ");
						a.setFirstName(sc.next());
						break;
	
					case '2':
						System.out.print("Enter Middle Name: ");
						a.setMiddleName(sc.next());
						break;
						
					case '3':
						System.out.print("Enter Last Name: ");
						a.setLastName(sc.next());
						break;
					
					case '4':
						System.out.print("Enter Phone No.: ");
						a.setPhoneNo(sc.next());
						break;
					
					default:
						break;
						
					}
					
				em.persist(a);
				em.getTransaction().commit();
				break;
	
			case '3':
				a=new Author();
				em.getTransaction().begin();
				System.out.println("Enter Author ID: ");
				a=em.find(Author.class, sc.nextInt());
				em.remove(a);
				em.getTransaction().commit();
				break;
	
			case '4':
					Query q=em.createQuery("Select a from Author a where a.firstName='Anuja'");
					List<Author> lAuthor=q.getResultList();
					/*for(Author o:lAuthor)
						System.out.println(o);*/
					lAuthor.parallelStream().forEach(System.out::println);
					
					q=em.createQuery("Select a from Author a");
					lAuthor=q.getResultList();
					lAuthor.parallelStream().forEach(System.out::println);
					
					
					
					
				break;
				
			case '5':
				em.close();
				emf.close();
				sc.close();
				System.exit(0);
				
			
			default:
				System.out.println("Invalid Choice");
				break;
				
			}
		System.out.print("1.Insert 2.Update 3.Delete 4.Show All 5.Exit\nEnter Choice: ");
		key=sc.next().charAt(0);
		}
	}
}
