package com.cg.entity;

import javax.persistence.Embeddable;

@Embeddable
public class BookDetail {


		private String ISBN;
		private String title;
		private double price;
		
		public BookDetail(String iSBN, String title, double price) {
			super();
			ISBN = iSBN;
			this.title = title;
			this.price = price;
		}
		
		public BookDetail() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		public String getISBN() {
			return ISBN;
		}
		public void setISBN(String iSBN) {
			ISBN = iSBN;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		@Override
		public String toString() {
			return "BookDetail [ISBN=" + ISBN + ", title=" + title + ", price=" + price + "]";
		}
		
		
		
		
	}

	