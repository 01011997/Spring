package com.cg.entity;

import javax.persistence.Embeddable;

@Embeddable
public class AuthorDetail {

	private String ID;
	private String name;
	
	
	public AuthorDetail(String iD, String name) {
		super();
		ID = iD;
		this.name = name;
	}
	
	
	public AuthorDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	@Override
	public String toString() {
		return "AuthorDetail [ID=" + ID + ", name=" + name + "]";
	}
	
	
	
	
}
