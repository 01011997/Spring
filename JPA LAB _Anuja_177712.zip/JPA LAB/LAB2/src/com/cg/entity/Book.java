package com.cg.entity;

import java.util.List;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

@NamedQueries(@NamedQuery(name="selectAll",query="select b from Book b"))

@Entity
public class Book {

	
	@Id
	@GeneratedValue
	private int bookId;
	@Embedded
	private BookDetail book;
	@OneToMany 
	private List<AuthorDetail> author;
	
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public BookDetail getBook() {
		return book;
	}
	public void setBook(BookDetail book) {
		this.book = book;
	}
	public List<AuthorDetail> getAuthor() {
		return author;
	}
	public void setAuthor(List<AuthorDetail> author) {
		this.author = author;
	}
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", book=" + book + ", author=" + author + "]";
	}
	public Book(int bookId, BookDetail book, List<AuthorDetail> author) {
		super();
		this.bookId = bookId;
		this.book = book;
		this.author = author;
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
