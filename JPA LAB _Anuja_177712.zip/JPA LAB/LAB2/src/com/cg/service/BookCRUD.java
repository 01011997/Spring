package com.cg.service;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.entity.AuthorDetail;
import com.cg.entity.Book;
import com.cg.entity.BookDetail;

public class BookCRUD {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("LAB2");
		EntityManager em=emf.createEntityManager();
		Scanner sc=new Scanner(System.in);
		BookDetail bookDetail;
		AuthorDetail authorDetail;
		Book book;
		char key;
		
		while(true) {
			System.out.println("(1)Insert (2)Show By Id (3)Show All (4)Show where price between 500 &1000 (5)Exit");
			key=sc.next().charAt(0);
			switch (key) {
			case '1':
				bookDetail=new BookDetail();	
				authorDetail=new AuthorDetail();
				book=new Book();
				System.out.print("Enter ISBN");
				bookDetail.setISBN(sc.next());
				System.out.print("Enter Book Title");
				bookDetail.setTitle(sc.next());
				System.out.print("Enter Book Price");
				bookDetail.setPrice(Double.parseDouble(sc.next()));
				
				System.out.print("Enter Author ID: ");
				authorDetail.setID(sc.next());
				System.out.print("Enter Author Name: ");
				authorDetail.setName(sc.next());
				
				em.getTransaction().begin();
				book.setAuthor(authorDetail);
				book.setBook(bookDetail);
				em.persist(book);
				em.getTransaction().commit();
				
				System.out.println("BOOK ID: "+book.getBookId());
				
				break;

			case '2':
				System.out.println("Enter Book Id: ");
				Book b=em.find(Book.class, sc.next());
				System.out.println(b);
				break;
				
			case '3':
				Query q1=em.createQuery("select b from Book b");
				List<Book> allBooks=q1.getResultList();
				allBooks.stream().forEach(System.out::println);
				break;
				
			case '4':
				Query q2=em.createQuery("select b from Book b where b.price >100 ");
				List<Book> bookList=q2.getResultList();
				bookList.stream().forEach(System.out::println);
				break;
				
			case '5':
				em.close();
				emf.close();
				System.exit(0);
				break;
				
			default:
				break;
			}
			
			
			
			
			
			
			
		}
		
		
		
		
		
		
		
	}

}
